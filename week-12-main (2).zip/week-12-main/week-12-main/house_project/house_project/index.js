class Document {
    constructor(name) {
        this.name = name;
        this.peragraph = [];
    }

    addPeragraph(name, area) {
        this.peragraph.push(new Peragraph(name, area))
    }
}

class Peragraph {
    constructor(name, area) {
        this.name = name;
        this.area = area;
    }
}

class DocumentServes {
    static url = 'https://ancient-taiga-31359.herokuapp.com/api/document';

    static getAllDocument() {
        return $.get(this.url);
    }

    static getDocument(id) {
        return $.get(this.url + '/$(id)');
    }

    static createDocument(document) {
        return $.post(this.url, document);
    }

    static updateDocument(document) {
        return $.ajax({
            url: this.url + '/$(document._id)',
            dataType: 'json',
            data: JSON.stringify(document),
            contentType: 'application/json',
            type: 'Put'
        });
    }

    static deleteDocument(id) {
        return $.ajax({
            url: this.url + '/$(id)',
            type: 'DELETE'
        });
    }
}

class DOMManager {
    static Document;

    static getAllDocument() {
        DocumentServes.getAllDocument().then(document => this.render(document));
    }

    static createDocument(name) {
        DocumentServes.createDocument(new document(name))
            .then(() => {
                return DocumentServes.getAllDocument();
            })
            .then((document) => this.render(Document));
    }

    static deleteDocument(id) {
        DocumentServes.deleteDocument(id)
            .then(() =>{
                return DocumentServes.getAllDocument();
            })
            .then((document) => this.render(this.Document));
    }

    static addPeragraph(id) {
        for (let document of this.Document) {
            if(document._id == id) {
                document.peragraph.push(new Peragraph($(`#${document._id}-peragraph-name`).val(), $(`#${document._id}-peragraph-area`).val()));
                DocumentServes.updateDocument(document)
                    .then(() => {
                        return DocumentServes.getAllDocument();
                    })
                    .then((Document) => this.render(Document));
            }
        }
    }

    static deletePeragraph(documentId, peragraphId) {
        for (let document of this.Document) {
            if (document._id == document._id) {
                for (let peragraph of document.peragraph) {
                    if (peragraph._id == peragraphId) {
                        document.peragraph.splice(document.peragraph.indexOf(peragraph), 1);
                        DocumentServes.updateDocument(document)
                            .then(() => {
                                return DocumentServes.getAllDocument();
                            })
                            .then((Document) => this.render(Document));
                    }
                }
            }
        }
    }

    static render(document) {
        this.document = document;
        $('#app').empty();
        for (let Document of document) {
            $('#app').prepend(
                `<div id="${document._id}" class="card">
                   <div class="card-header">
                      <h2>${document.name}</h2>
                      <button class="bin btn-danger" onclick="DOMManager.deleteDocument('${document._id}');">Delete</button>
                    </div>
                    <div clas="card-body">
                      <div class="card">
                        <div class="row">
                          <div class="col-sm">
                            <imput type="text" id="${document._id}-peragraph-name" class="form-control" placeholder="Peragraph Name">
                          </div>
                          <div class="col-sm">
                            <imput type="text" id="${document._id}-peragraph-area" class="form-control" placeholder="Peragraph Area">
                          </div>
                        </div>
                        <button id="${document._id}-new-peragraph" onclick="DOMManager.addPeragraph('${document._id}')" class="btn btn-primery form-control">Add</button>
                      </div>
                    </div>
                </div><br>`
            );
            for (let peragraph of document.peragraph) {
                $(`#${document._id}`).find('.card-body').append(
                    `<p>
                      <span id="name-${peragraph_id}"><strong>Name: </strong> ${peragraph.name}</span>
                      <span id="area-${peragraph_id}"><strong>Area: </strong> ${peragraph.area}</span>
                      <button class="btn btn-danger" onclick="DOMManager.deletePeragraph('${document._id}', '${peragraph._id})">Delete Peragraph</button>`
                )
            }
        }
    }
}

$('#create-new-document').click(() => {
    DOMManager.createDocument($('#new-document-name').val());
    $('#new-document-name').val('');
})

DOMManager.getAllDocument();